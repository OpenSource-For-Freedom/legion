# Legion Dev LoRA run iterate-20260706T205556Z (execution-verified)

**Status:** ok

## Configuration
- run_id: 20260706T205556Z
- tier: legion-dev:qwen2.5-coder-1.5b
- base_model: Qwen/Qwen2.5-Coder-1.5B-Instruct
- teacher_model: qwen2.5-coder:7b
- time_budget_min: 240.0
- instructions_per: 3
- smoke: False
- wall_clock_min: 103.9
- cycles: 6

## Dataset
- candidates: 45
- accepted:   45
- rejected:   0
- deduped:    8
- train/val/test: 30/7/5
- by backend: {'model': 37}

## Training
- status:     ok
- base model: Qwen/Qwen2.5-Coder-1.5B-Instruct
- steps done: 150
- wall-clock: 399s (budget 45 min)
- adapter:    F:\dev\legion-agent\legion_dev\.work\iter-20260706T205556Z\cycle1\adapter
- detail:     completed

## Build
  (none)

## Evaluation — candidate
  pass@1 (execution): 4/5 (0.80)
  produced code:      5/5
  mean latency:       6.0s
  gates cleared:      True

## Evaluation — baseline
  pass@1 (execution): 3/5 (0.60)
  produced code:      5/5
  mean latency:       2.8s
  gates cleared:      True

## Promote decision
- promote: True
- reason:  candidate clears gates and matches/beats baseline (0.80 >= 0.60)
