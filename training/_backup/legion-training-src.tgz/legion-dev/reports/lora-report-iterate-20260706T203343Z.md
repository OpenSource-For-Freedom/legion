# Legion Dev LoRA run iterate-20260706T203343Z (execution-verified)

**Status:** ok

## Configuration
- run_id: 20260706T203343Z
- tier: legion-dev:qwen2.5-coder-3b
- base_model: Qwen/Qwen2.5-Coder-0.5B-Instruct
- teacher_model: qwen2.5-coder:7b
- time_budget_min: 10.0
- instructions_per: 3
- smoke: True
- wall_clock_min: 3.7
- cycles: 1

## Dataset
- candidates: 15
- accepted:   15
- rejected:   0
- deduped:    0
- train/val/test: 12/3/5
- by backend: {'reference': 15}

## Training
- status:     ok
- base model: Qwen/Qwen2.5-Coder-0.5B-Instruct
- steps done: 2
- wall-clock: 5s (budget 5 min)
- adapter:    F:\dev\legion-agent\legion_dev\.work\iter-20260706T203343Z\cycle1\adapter
- detail:     completed

## Build
  (none)

## Evaluation — candidate
  pass@1 (execution): 2/5 (0.40)
  produced code:      5/5
  mean latency:       19.9s
  gates cleared:      False

## Evaluation — baseline
  pass@1 (execution): 2/5 (0.40)
  produced code:      5/5
  mean latency:       12.9s
  gates cleared:      False

## Promote decision
- promote: False
- reason:  candidate did not clear all eval gates
