---
license: apache-2.0
---

<!-- legiondev:latest-run:start -->

## Latest training run

- run `20260706T205556Z` · status **ok** · tier legion-dev:qwen2.5-coder-1.5b · teacher qwen2.5-coder:7b · 6 sweep cycles in 103.9 min
- method: execution-verified self-distillation — the local coder teacher's solutions are kept only when they pass real pytest tests; graded by pass@1 on a held-out task set (bug-fix, implement-from-spec, refactor, edge-case, SQL-injection, hardcoded-secret)

| metric | base | trained |
|---|---|---|
| pass@1 (execution) | 3/5 | 4/5 |
| produced code | 5/5 | 5/5 |
| gates cleared | True | True |

Promote decision: **True** — candidate clears gates and matches/beats baseline (0.80 >= 0.60)

<!-- legiondev:latest-run:end -->
